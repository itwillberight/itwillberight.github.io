// JavaScript Document

//全局js
$(function(){
//start

$('.cnav a:first').click(function(){
	if(!$(this).hasClass('hide')){
		$(this).children('p').text('展开');
		$(this).addClass('hide').nextAll(':not(:last)').css('display','none');
	}else{
		$(this).children('p').text('收起');
		$(this).removeClass('hide').nextAll(':not(:last)').css('display','block');
	}
});

$('#body').css('min-height',$(window).height()-270);
$(window).resize(function(){
	$('#body').css('min-height',$(window).height()-270);
});

$(".gotop").click(function(){
	$("html").animate({scrollTop:0},400+$(window).scrollTop()*0.3);
	if(navigator.appVersion.match("WebKit")){
		$("body").animate({scrollTop:0},400+$(window).scrollTop()*0.3);
	}
	else{
		$("html").animate({scrollTop:0},400+$(window).scrollTop()*0.3);
	}
});

$('#footer .f1 .yl').on('mouseenter',function(){
	$('#footer .f1 .up').fadeIn(300);
});
$('#footer .f1').on('mouseleave',function(){
	$('#footer .f1 .up').fadeOut(300);
});

$('#header .head2 .nav .li.e').hover(function(){
	if($(this).find('.hide').length>0){
		$(this).find('.hide').stop().fadeToggle(300);
	}
});
$('#header .head2 .nav .li.e').hover(function(){
	if($(this).find('.hide').length>0){
		$('#navblack').stop().fadeToggle(300);
	}
});

$('#header .head1 .select').hover(function(){
	$(this).find('.hide').stop().toggle();
});

$('.cnav a').hover(function(){
	$(this).find('.up').stop().fadeToggle(300);
});

//**//
$('.tab-wrap').each(function(index, element) {
	var _this=$(this);
  var bar=_this.find('.tab-bar').find('li');
	var items=_this.find('.tab-item');
	if(bar.length>1){
		items.eq(_this.find('.tab-bar').find('.act').index()).css('display','block').siblings('.tab-item').css('display','none');
		bar.on('mouseenter',function(){
			if(!$(this).hasClass('act')){
				$(this).addClass('act').siblings('li').removeClass('act');
				items.eq($(this).index()).css('display','block').siblings('.tab-item').css('display','none');
			}
		});
	}
});


//end
});
