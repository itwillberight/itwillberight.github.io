﻿$.extend($.validator.messages, {
    required: '该项不得为空',
    email: '请输入有效的邮件地址',
    url: '请输入有效的URL地址',
    date: '请输入有效的日期',
    dateISO: '请输入有效的日期(ISO)',
    number: '请输入有效的数字',
    digits: '只能输入整数',
    equalTo: '请再次输入相同的值',
    minlength: $.validator.format("长度不应小于{0}个字符"),
    maxlength: $.validator.format("长度不应大于{0}个字符"),
    rangelength: $.validator.format("长度应介于{0}到{1}个字符之间"),
    range: $.validator.format("请输入介于{0}和{1}之间的值"),
    max: $.validator.format("请输入一个最大为{0}的值"),
    min: $.validator.format("请输入一个最小为{0}的值"),
    phonenum: '请输入有效的手机号码',
    pwdCheck: '密码应至少8位，包含数字和字母'
});

jQuery.validator.addMethod("phonenum", function (value, element) {
    var returnVal = false;
    var length = value.length;
    var regPhone = /^1[3589]\d{9}$/;
    return this.optional(element) || (length == 11 && regPhone.test(value));
}, "请输入有效的手机号码");

jQuery.validator.addMethod("pwdCheck", function (value, element) {
    var mediumRegex = new RegExp("^(?=.{8,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g");
    return mediumRegex.test(value);
}, "密码应至少8位，包含数字和字母");